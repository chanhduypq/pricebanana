/**
 * 脚本注入方法
 * u : URL地址
 * c : 编码utf8、gbk 等
 */
function insertScript(u,c){
	var b = document.createElement('script'); b.type = 'text/javascript'; b.charset=c; b.src=u;
	var s = document.getElementsByTagName('script')[0] || document.getElementsByTagName('body')[0] || false;
	if(s===false) return false;
	s.parentNode.insertBefore(b, s);
	return true;
}

var run = function(){
	//console.log('注入脚本');
	// 百度JS模版引擎
	insertScript(chrome.extension.getURL("baiduTemplate.js"),'utf-8'); 
	// JQuery
	//insertScript(chrome.extension.getURL("jquery.js"),'utf-8');
	
	// 创建script对象
	var script = document.createElement('script');
	// 添加ID
	script.setAttribute('id','sgScript');
	// 存入注入js方法
	script.innerHTML = insertScript.toString();
	// 引入jquery
	script.innerHTML += 'if(!(window.jQuery && $)){ insertScript("'+chrome.extension.getURL("jquery.js")+'");}';
	// 引入主js
	//script.innerHTML += "insertScript('//www.sgshop.com/public/js/onekey.js','utf-8')";
	script.innerHTML += "insertScript('//tool.onebound.cn/ShopTool/chrome/yeslogistics.com.my/onekey.js','utf-8')";
	document.body.appendChild(script);

	// 发送消息
	chrome.extension.sendRequest({showico: true}, function(result) {
		//console.log(result);
		if(result.showico=='ok'){
			// 监听消息
			chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
				/*console.log({
					request : request,
					sender : sender,
					sendResponse : sendResponse
				});*/
				// 因为点击之后，所有页面都会响应，所以加上tab.id进行判断
				if(result.sender.tab.id == request.tab.id && request.action=='click'){
					var sg_addto = document.getElementsByClassName('sg_addto');
					if(sg_addto.length>0) sg_addto[0].click();
				}
			});
		}
	});
};
// 如果存在body才执行
if(document.body) run();