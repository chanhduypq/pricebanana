// 监听消息
chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
	/*sendResponse({
		request : request,
		sender : sender,
		sendResponse : sendResponse
	});*/
	if (true === request.showico) {
		// 发送回调调息
		sendResponse({
			showico:'ok',
			request : request,
			sender : sender
		});
		// 显示图标
		chrome.pageAction.show(sender.tab.id);
		// 点击事件
	    chrome.pageAction.onClicked.addListener(function(tab) {
	    	// 发送回调调息
	    	chrome.tabs.sendRequest(sender.tab.id, {action: "click", tab:tab});
	    });
	}
});